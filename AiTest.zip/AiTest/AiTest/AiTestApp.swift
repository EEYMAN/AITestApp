// Alexandr Kovalskiy 28.05.2025

import SwiftUI

@main
struct AiTestApp: App {
    var body: some Scene {
        WindowGroup {
            SessionsListView()
        }
    }
}
